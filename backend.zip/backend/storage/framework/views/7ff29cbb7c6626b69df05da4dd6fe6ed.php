<?php $__env->startSection('admin'); ?>
    <div class="content">
        <!-- Start Content-->
        <div class="container-xxl">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                <div class="flex-grow-1">
                    <h4 class="fs-18 fw-semibold m-0">Top Navbar Settings</h4>
                </div>
            </div>

            <!-- Form for updating settings -->
            <div class="row">
                <div class="col-12">

                    
                    <form action="<?php echo e(route('update.topnav', $topnav->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <!-- First Card: Contact Information -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Contact Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- Address Input -->
                                    <div class="col-md-6 mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i data-feather="map-pin"
                                                    class="icon-sm"></i></span>
                                            <input type="text" class="form-control" id="address" name="address"
                                                placeholder="Street 2011, #290 , Phnom Penh, Cambodia"
                                                value="<?php echo e($topnav->address ?? ''); ?>">
                                        </div>
                                    </div>
                                    <!-- Email Input -->
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i data-feather="mail"
                                                    class="icon-sm"></i></span>
                                            <input type="email" class="form-control" id="email" name="email"
                                                placeholder="company-email@example.com" value="<?php echo e($topnav->email ?? ''); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Second Card: Social Media Links -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Social Media Links</h5>
                                <p class="card-subtitle mt-1 text-muted">Enter the full URL for each social media profile.
                                    Use the toggles to show or hide the icon on the website.</p>
                            </div>


                            <div class="card-body">
                                <div class="row g-3">

                                                        
                                    <?php
                                        $socials = [
                                            'facebook' => ['icon' => 'facebook', 'label' => 'Facebook'],
                                            'linkedin' => ['icon' => 'linkedin', 'label' => 'LinkedIn'],
                                            'twitter' => ['icon' => 'twitter', 'label' => 'X (Twitter)'],
                                            'instagram' => ['icon' => 'instagram', 'label' => 'Instagram'],
                                            'youtube' => ['icon' => 'youtube', 'label' => 'YouTube'],
                                            'telegram' => ['icon' => 'send', 'label' => 'Telegram'],
                                        ];
                                    ?>

                                                        
                                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <label for="<?php echo e($key); ?>_url"
                                                class="form-label"><?php echo e($details['label']); ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i data-feather="<?php echo e($details['icon']); ?>"
                                                        class="icon-sm"></i></span>

                                                                    
                                                <input type="url" class="form-control" id="<?php echo e($key); ?>_url"
                                                    name="<?php echo e($key); ?>_url" placeholder="https://..."
                                                    value="<?php echo e($topnav->{$key . '_url'} ?? ''); ?>">

                                                <div class="input-group-text">
                                                    <div class="form-check form-switch">
                                                                            
                                                        <input class="form-check-input" type="checkbox" role="switch"
                                                            id="<?php echo e($key); ?>_status"
                                                            name="<?php echo e($key); ?>_status"
                                                            <?php if($topnav->{$key . '_status'} ?? false): ?> checked <?php endif; ?>>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>



                        </div>

                        <!-- Submit Button -->
                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>

                    </form>
                </div>
            </div>

        </div> <!-- container-xxl -->
    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/backend/top-navbar/top_navbar.blade.php ENDPATH**/ ?>