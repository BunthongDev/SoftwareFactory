<?php $__env->startSection('admin'); ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script src="https://cdn.tiny.cloud/1/iy88y3uptlb8z04w36zu58bjw0kyht0a0h05yviaf5hyl3jk/tinymce/8/tinymce.min.js" referrerpolicy="origin"></script>

<div class="content">
    <div class="container-xxl">
        <div class="py-3">
            
        </div>

        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Add New Blog Post</h5>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('blog.store')); ?>" method="post" class="row g-3" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="col-md-8">
                                <label for="title" class="form-label">Post Title</label>
                                <input type="text" name="title" class="form-control" placeholder="Enter post title" required>
                            </div>

                            <div class="col-md-4">
                                <label for="category" class="form-label">Category</label>
                                <input type="text" name="category" class="form-control" placeholder="e.g., App Development, Web Development" required>
                            </div>

                            <div class="col-md-12">
                                <label for="tags" class="form-label">Tags (Comma Separated)- optional </label>
                                <input type="text" name="tags" class="form-control" placeholder="e.g., featured, skill, business">
                            </div>

                            <div class="col-md-12">
                                <label for="excerpt" class="form-label">Excerpt / Short Description - optional</label>
                                <textarea name="excerpt" class="form-control" rows="3" placeholder="Enter a short summary of the post"></textarea>
                            </div>

                            <div class="col-md-12">
                                <label for="content" class="form-label">Full Content - optional</label>
                                
                                <textarea name="content" class="form-control" id="content_editor" rows="10"></textarea>
                            </div>

                            <div class="col-md-6">
                                <label for="image_input" class="form-label">Main Feature Image</label>
                                <input type="file" name="image" class="form-control" id="image_input" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Image Preview</label>
                                <div class="d-flex align-items-center justify-content-center" style="min-height: 150px; border: 1px dashed #ced4da; border-radius: 0.25rem;">
                                    <img id="image_preview" src="<?php echo e(url('upload/no_image.jpg')); ?>" alt="Image Preview" style="max-width: 100%; max-height: 150px;">
                                </div>
                            </div>

                            <hr class="my-4">

                             <div class="col-md-4">
                                <label for="author_name" class="form-label">Author Name</label>
                                <input type="text" name="author_name" class="form-control" placeholder="Default is 'Admin'" required>
                            </div>

                            <div class="col-md-4">
                                <label for="published_at" class="form-label">Publish Date - optional</label>
                                <input type="datetime-local" name="published_at" class="form-control">
                            </div>

                            <div class="col-md-6">
                                <label for="avatar_input" class="form-label">Author Avatar - optional</label>
                                <input type="file" name="author_avatar" class="form-control" id="avatar_input">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Avatar Preview</label>
                                <div class="d-flex align-items-center justify-content-center" style="width: 100px; height: 100px; border: 1px dashed #ced4da; border-radius: 50%;">
                                    <img id="avatar_preview" src="<?php echo e(url('upload/no_image.jpg')); ?>" alt="Avatar Preview" style="max-width: 100%; max-height: 100px; border-radius: 50%;">
                                </div>
                            </div>

                            <div class="col-12">
                                <button class="btn btn-primary" type="submit">Save Post</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function() {
        // Main image preview
        $('#image_input').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image_preview').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files[0]);
        });

        // Author avatar preview
        $('#avatar_input').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#avatar_preview').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files[0]);
        });
    });
</script>


<script>
  tinymce.init({
    selector: 'textarea#content_editor',
    plugins: 'anchor autolink charmap codesample emoticons link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange formatpainter pageembed a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode advtemplate ai mentions tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss markdown importword exportword exportpdf',
    toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
    
    // Added Battambang to the font list
    font_family_formats: 'Andale Mono=andale mono,times; Arial=arial,helvetica,sans-serif; Arial Black=arial black,avant garde; Book Antiqua=book antiqua,palatino; Battambang=battambang,sans-serif; Comic Sans MS=comic sans ms,sans-serif; Courier New=courier new,courier; Georgia=georgia,palatino; Helvetica=helvetica; Impact=impact,chicago; Symbol=symbol; Tahoma=tahoma,arial,helvetica,sans-serif; Terminal=terminal,monaco; Times New Roman=times new roman,times; Trebuchet MS=trebuchet ms,geneva; Verdana=verdana,geneva; Webdings=webdings; Wingdings=wingdings,zapf dingbats',
    
    // Added the Google Font link for Battambang
    content_css: 'https://fonts.googleapis.com/css2?family=Battambang:wght@400;700&display=swap',

    tinycomments_mode: 'embedded',
    tinycomments_author: 'Author name',
    mergetags_list: [
      { value: 'First.Name', title: 'First Name' },
      { value: 'Email', title: 'Email' },
    ],
    ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/backend/blog/create.blade.php ENDPATH**/ ?>