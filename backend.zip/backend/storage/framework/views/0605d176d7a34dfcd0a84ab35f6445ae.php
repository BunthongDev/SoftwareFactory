<?php $__env->startSection('admin'); ?>

    <div class="content">

        <!-- Start Content-->
        <div class="container-xxl">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">



            </div>

            <!-- Form Validation -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Edit Slider</h5>
                        </div><!-- end card header -->

                        <div class="card-body">

                            <form action="<?php echo e(route('update.slider', $slider->id)); ?>" method="post" class="row g-3"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" name="id" value="<?php echo e($slider->id); ?>">

                                <div class="col-md-6">
                                    <label for="validationDefault01" class="form-label">Slider Heading</label>
                                    <input type="text" name="heading" class="form-control value"
                                        value="<?php echo e($slider->heading); ?>">
                                </div>

                                <div class="col-md-6">
                                    <label for="validationDefault01" class="form-label">Slider Link</label>
                                    <input type="text" name="link" class="form-control value"
                                        value="<?php echo e($slider->link); ?>">
                                </div>

                                <div class="col-md-12">
                                    <label for="validationDefault01" class="form-label">Slider Description</label>
                                    <textarea name="description" class="form-control" placeholder="Enter Slider Description"><?php echo e($slider->description); ?></textarea>
                                </div>

                                <div class="col-md-6">
                                    <label for="validationDefault01" class="form-label">Slider Image</label>
                                    <input type="file" name="image" class="form-control" id="image">
                                </div>
                                <div class="col-md-6">
                                    <img id="ShowImage" src="<?php echo e(asset($slider->image)); ?>"
                                        class="rounded-circle avatar-xxl img-thumbnail float-start" alt="image slider ">

                                </div>


                                <div class="col-12">
                                    <button class="btn btn-primary" type="submit">Save Changes</button>
                                </div>
                            </form>
                        </div> <!-- end card-body -->
                    </div> <!-- end card-->
                </div> <!-- end col -->



            </div> <!-- container-fluid -->

        </div>


        <script type="text/javascript">
            $(document).ready(function() {
                $('#image').change(function(e) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#ShowImage').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(e.target.files['0']);
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/backend/slider/edit_slider.blade.php ENDPATH**/ ?>