
<div style="display: flex; align-items: center; gap: 16px;">
    <img src="<?php echo e(asset('backend/assets/images/logo-light-mode.png')); ?>" alt="Logo" height="260" width="260" style="display: block;" />

</div><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/components/application-logo.blade.php ENDPATH**/ ?>