<?php $__env->startSection('admin'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>


    <div class="content">

        <!-- Start Content-->
        <div class="container-xxl">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                

                
            </div>

            <!-- Form Validation -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">All Slider</h5>
                        </div><!-- end card header -->

                        <div class="card-body">
                            
        <form action="<?php echo e(route('store.slider')); ?>" method="post" class="row g-3" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-md-6">
                <label for="validationDefault01" class="form-label">Slider Heading</label>
                <input type="text" name="heading" class="form-control" placeholder="Enter slider heading (Optional)">
            </div>
            
             <div class="col-md-6">
                <label for="validationDefault01" class="form-label">Slider Link</label>
                <input type="text" name="link" class="form-control" placeholder="Enter Slider Link" required>
            </div>
            
            <div class="col-md-12">
                <label for="validationDefault01" class="form-label">Slider Description</label>
                <textarea name="description" class="form-control" placeholder="Enter Slider Description (Optional)"></textarea>
            </div>
            
            <div class="col-md-6">
                <label for="validationDefault01" class="form-label">Slider Image</label>
                <input type="file" name="image" class="form-control" id="image">
            </div>
            <div class="col-md-6">
                 <img id="ShowImage" src="<?php echo e(url('upload/no_image.jpg')); ?>" class="rounded-circle avatar-xxl img-thumbnail float-start" alt="image slider ">

            </div>
            
            
            <div class="col-12">
                <button class="btn btn-primary" type="submit">Save Changes</button>
            </div>
        </form>
                        </div> <!-- end card-body -->
                    </div> <!-- end card-->
                </div> <!-- end col -->



            </div> <!-- container-fluid -->

        </div>
        
        
        <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#ShowImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
        
    </script>
        
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/backend/slider/add_slider.blade.php ENDPATH**/ ?>