<?php $__env->startSection('admin'); ?>

<div class="content">
    <div class="container-xxl">
        <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
            <div class="flex-grow-1">
                <h4 class="fs-18 fw-semibold m-0">All Testimonials</h4>
            </div>
            <div class="ps-sm-3 mt-sm-0 mt-2">
                <a href="<?php echo e(route('testimonial.create')); ?>" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i> Add New Testimonial</a>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Avatar</th>
                                        <th>Name</th>
                                        <th>Role</th>
                                        <th>Quote</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><img src="<?php echo e(asset($item->avatar)); ?>" style="width: 50px; height: 50px; border-radius: 50%;"></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->role); ?></td>
                                        <td><?php echo e(Str::limit($item->quote, 500)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('testimonial.edit', $item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                            <form action="<?php echo e(route('testimonial.destroy', $item->id)); ?>" method="POST" class="d-inline" id="delete-form-<?php echo e($item->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm delete-button">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/backend/testimonial/index.blade.php ENDPATH**/ ?>