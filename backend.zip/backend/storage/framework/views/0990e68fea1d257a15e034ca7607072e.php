<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col fs-13 text-muted text-center">
                &copy; <script>document.write(new Date().getFullYear())</script> | AnajakSoftware. All Rights Reserved.
            </div>
        </div>
    </div>
</footer><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/admin/body/footer.blade.php ENDPATH**/ ?>