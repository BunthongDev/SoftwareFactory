<?php $__env->startSection('admin'); ?>
    <div class="content">

        <div class="container-xxl">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Edit Case Study</h5>
                        </div>
                        <div class="card-body">

                            
                            <form action="<?php echo e(route('update.casestudy', $casestudy->id)); ?>" method="post" class="row g-3"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                
                                <input type="hidden" name="id" value="<?php echo e($casestudy->id); ?>">


                                <div class="col-md-12">
                                    <label for="title" class="form-label">Case Study Title</label>
                                    <input type="text" name="title" class="form-control"
                                        value="<?php echo e($casestudy->title); ?>">
                                </div>


                                <div class="col-md-12">
                                    <label for="description" class="form-label">Case Study Descriptio (Optional)</label>
                                    <textarea name="description" class="form-control" placeholder="Enter Case Study Description"><?php echo e($casestudy->description); ?></textarea>
                                </div>


                                <div class="col-md-6">
                                    <label for="image" class="form-label">Case Study Image ( 500x350px )</label>
                                    <input type="file" name="image" class="form-control" id="image">
                                </div>

                                
                                <div class="col-md-6">
                                    <img id="ShowImage" src="<?php echo e(asset($casestudy->image)); ?>"
                                        style="width: 200px; height: auto; border: 1px solid #ddd; padding: 5px;"
                                        alt="Case Study Image">
                                </div>

                                <div class="col-12">
                                    <button class="btn btn-primary" type="submit">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    
    
    
    
    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#ShowImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/HaruMalik/Desktop/Project NextJs-Laravel/SoftwareFactory/backend/resources/views/backend/case-study/edit_case_study.blade.php ENDPATH**/ ?>