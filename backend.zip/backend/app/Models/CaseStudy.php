<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CaseStudy extends Model
{
    protected $guarded = []; // This allows mass assignment for all attributes, you can specify fields if needed
}
