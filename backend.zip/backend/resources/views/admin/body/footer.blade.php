<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col fs-13 text-muted text-center">
                &copy; <script>document.write(new Date().getFullYear())</script> | AnajakSoftware. All Rights Reserved.
            </div>
        </div>
    </div>
</footer>