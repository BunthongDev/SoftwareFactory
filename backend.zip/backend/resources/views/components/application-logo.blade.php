{{-- Application Logo --}}
<div style="display: flex; align-items: center; gap: 16px;">
    <img src="{{ asset('backend/assets/images/logo-light-mode.png') }}" alt="Logo" height="260" width="260" style="display: block;" />

</div>